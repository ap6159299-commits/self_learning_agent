"""
Memory Manager Module.
Provides high-level interfaces for short-term working state, episodic trace storage,
and lesson retrieval.
"""

import re
from uuid import uuid4
from typing import List, Optional
from schemas import Task, ExecutionResult
from memory.sqlite_db import SQLiteDatabase


class MemoryManager:
    """
    Layered Memory Manager managing Tasks, Executions, Memories, and Lessons in SQLite.
    """

    def __init__(self, db: Optional[SQLiteDatabase] = None):
        """
        Initialize MemoryManager.

        Args:
            db: Optional SQLiteDatabase instance. Defaults to new connection manager.
        """
        self.db = db or SQLiteDatabase()

    def save_task(self, task: Task) -> None:
        """Saves or updates a task record in SQLite."""
        sql = """
        INSERT INTO tasks (id, prompt, status, updated_at)
        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ON CONFLICT(id) DO UPDATE SET
            status = excluded.status,
            updated_at = CURRENT_TIMESTAMP;
        """
        conn = self.db.get_connection()
        conn.execute(sql, (task.id, task.prompt, task.status.value))
        conn.commit()
        if not self.db._is_in_memory:
            conn.close()

    def save_execution(self, result: ExecutionResult) -> None:
        """Saves or updates an execution attempt record into SQLite."""
        sql = """
        INSERT INTO executions (id, task_id, attempt_number, generated_code, stdout, stderr, exit_code, execution_time_ms, passed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            stdout = excluded.stdout,
            stderr = excluded.stderr,
            exit_code = excluded.exit_code,
            execution_time_ms = excluded.execution_time_ms,
            passed = excluded.passed;
        """
        conn = self.db.get_connection()
        conn.execute(sql, (
            result.execution_id,
            result.task_id,
            result.attempt_number,
            result.generated_code,
            result.stdout,
            result.stderr,
            result.exit_code,
            result.execution_time_ms,
            result.passed
        ))
        conn.commit()
        if not self.db._is_in_memory:
            conn.close()

    def save_lesson(
        self,
        task_id: str,
        execution_id: str,
        failure_category: str,
        root_cause: str,
        lesson_learned: str,
        remediation_rule: str
    ) -> str:
        """
        Saves a structured reflection lesson into SQLite.

        Returns:
            Generated lesson ID.
        """
        lesson_id = str(uuid4())
        sql = """
        INSERT INTO lessons (id, task_id, execution_id, failure_category, root_cause, lesson_learned, remediation_rule)
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """
        conn = self.db.get_connection()
        conn.execute(sql, (
            lesson_id,
            task_id,
            execution_id,
            failure_category,
            root_cause,
            lesson_learned,
            remediation_rule
        ))
        conn.commit()
        if not self.db._is_in_memory:
            conn.close()
        return lesson_id

    def get_relevant_lessons(self, prompt: str, limit: int = 3) -> List[str]:
        """
        Retrieves relevant historical lessons based on keyword matching in prompt.

        Args:
            prompt: Task prompt string.
            limit: Maximum number of lessons to return.

        Returns:
            List of remediation rule strings.
        """
        words = [w.lower() for w in re.findall(r"\w+", prompt) if len(w) > 3]
        conn = self.db.get_connection()

        try:
            if not words:
                sql = "SELECT remediation_rule FROM lessons ORDER BY created_at DESC LIMIT ?"
                rows = conn.execute(sql, (limit,)).fetchall()
                return [r["remediation_rule"] for r in rows]

            where_clauses = " OR ".join(["root_cause LIKE ?" or "remediation_rule LIKE ?" for _ in words])
            sql = f"""
            SELECT remediation_rule FROM lessons
            WHERE {where_clauses}
            ORDER BY created_at DESC
            LIMIT ?;
            """

            params = [f"%{word}%" for word in words] + [limit]
            rows = conn.execute(sql, params).fetchall()
            lessons = [r["remediation_rule"] for r in rows]
            if lessons:
                return lessons

            fallback_sql = "SELECT remediation_rule FROM lessons ORDER BY created_at DESC LIMIT ?"
            rows = conn.execute(fallback_sql, (limit,)).fetchall()
            return [r["remediation_rule"] for r in rows]

        finally:
            if not self.db._is_in_memory:
                conn.close()
