"""
SQLite Database Initialization and Connection Management Module.
Provides low-level DDL migration and connection context handlers.
Supports in-memory shared database connections for high-performance testing.
"""

import sqlite3
from typing import Optional
from config import settings


class SQLiteDatabase:
    """
    Manages SQLite database connections and table schemas.
    Supports file-backed databases and in-memory shared databases.
    """

    def __init__(self, db_path: Optional[str] = None):
        """
        Initialize database manager.
        
        Args:
            db_path: Path to SQLite file or ':memory:'. Defaults to settings.DB_PATH.
        """
        self.db_path = db_path or settings.DB_PATH
        self._is_in_memory = (self.db_path == ":memory:" or "mode=memory" in self.db_path)
        self._shared_conn: Optional[sqlite3.Connection] = None

        if self._is_in_memory:
            # Use shared connection for in-memory DB to preserve tables across calls
            self._shared_conn = sqlite3.connect(":memory:", check_same_thread=False)
            self._shared_conn.row_factory = sqlite3.Row

        self.init_db()

    def get_connection(self) -> sqlite3.Connection:
        """Returns a configured SQLite connection with row factory enabled."""
        if self._is_in_memory and self._shared_conn:
            return self._shared_conn

        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def close(self) -> None:
        """Closes shared in-memory connection if active."""
        if self._shared_conn:
            self._shared_conn.close()
            self._shared_conn = None

    def init_db(self) -> None:
        """Executes DDL scripts to create tasks, executions, memories, and lessons tables."""
        ddl_script = """
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY,
            prompt TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS executions (
            id TEXT PRIMARY KEY,
            task_id TEXT NOT NULL,
            attempt_number INTEGER NOT NULL,
            generated_code TEXT NOT NULL,
            stdout TEXT,
            stderr TEXT,
            exit_code INTEGER NOT NULL,
            execution_time_ms REAL NOT NULL,
            passed BOOLEAN NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(task_id) REFERENCES tasks(id)
        );

        CREATE TABLE IF NOT EXISTS memories (
            id TEXT PRIMARY KEY,
            task_id TEXT,
            memory_type TEXT NOT NULL,
            content TEXT NOT NULL,
            keywords TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(task_id) REFERENCES tasks(id)
        );

        CREATE TABLE IF NOT EXISTS lessons (
            id TEXT PRIMARY KEY,
            task_id TEXT NOT NULL,
            execution_id TEXT NOT NULL,
            failure_category TEXT NOT NULL,
            root_cause TEXT NOT NULL,
            lesson_learned TEXT NOT NULL,
            remediation_rule TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(task_id) REFERENCES tasks(id),
            FOREIGN KEY(execution_id) REFERENCES executions(id)
        );
        """
        conn = self.get_connection()
        conn.executescript(ddl_script)
        conn.commit()
        if not self._is_in_memory:
            conn.close()
