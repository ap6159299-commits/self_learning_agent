"""
Self-Learning Closed Loop Module.
Orchestrates multi-task execution sequences and tracks continuous performance improvement.
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from schemas import AgentState, TaskStatus
from agent import CodeAgent
from memory.memory_manager import MemoryManager


class TaskBatchSummary(BaseModel):
    """Aggregated benchmark metrics for a batch of task executions."""
    total_tasks: int
    successful_tasks: int
    pass_at_1_count: int
    pass_at_1_rate: float = Field(description="Percentage of tasks solved on attempt 1")
    total_attempts: int
    avg_attempts_per_task: float
    total_lessons_accumulated: int
    trajectories: List[Dict[str, Any]] = Field(default_factory=list)


class SelfLearningLoop:
    """
    Coordinates multi-task learning sequences and performance evaluations.
    """

    def __init__(
        self,
        agent: Optional[CodeAgent] = None,
        memory_manager: Optional[MemoryManager] = None
    ):
        """
        Initialize SelfLearningLoop.

        Args:
            agent: Optional CodeAgent instance.
            memory_manager: Optional MemoryManager instance.
        """
        self.agent = agent or CodeAgent()
        self.memory_manager = memory_manager or self.agent.memory_manager

    async def run_batch(self, prompts: List[str]) -> TaskBatchSummary:
        """
        Runs a sequential batch of coding task prompts, building online memory across runs.

        Args:
            prompts: List of natural language task prompts.

        Returns:
            TaskBatchSummary containing benchmark metrics and execution trajectories.
        """
        trajectories = []
        pass_at_1_count = 0
        successful_tasks = 0
        total_attempts = 0

        for prompt in prompts:
            state: AgentState = await self.agent.run(prompt)
            total_attempts += state.current_attempt

            is_success = (state.status == TaskStatus.SUCCESS)
            is_pass_1 = (is_success and state.current_attempt == 1)

            if is_success:
                successful_tasks += 1
            if is_pass_1:
                pass_at_1_count += 1

            trajectories.append({
                "task_id": state.task.id,
                "prompt": prompt,
                "status": state.status.value,
                "attempts": state.current_attempt,
                "lessons_applied_count": len(state.lessons_applied),
                "reflections_count": len(state.reflections)
            })

        total_tasks = len(prompts)
        pass_at_1_rate = round((pass_at_1_count / total_tasks) * 100.0, 2) if total_tasks > 0 else 0.0
        avg_attempts = round(total_attempts / total_tasks, 2) if total_tasks > 0 else 0.0

        # Query total lessons accumulated in memory
        with self.memory_manager.db.get_connection() as conn:
            total_lessons = conn.execute("SELECT COUNT(*) as cnt FROM lessons").fetchone()["cnt"]

        return TaskBatchSummary(
            total_tasks=total_tasks,
            successful_tasks=successful_tasks,
            pass_at_1_count=pass_at_1_count,
            pass_at_1_rate=pass_at_1_rate,
            total_attempts=total_attempts,
            avg_attempts_per_task=avg_attempts,
            total_lessons_accumulated=total_lessons,
            trajectories=trajectories
        )
