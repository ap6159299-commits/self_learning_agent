"""
Benchmark and Performance Evaluation Harness.
Renders structured evaluation reports and tracks Pass@1 learning curves.
"""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from learning.learning_loop import TaskBatchSummary

console = Console()


class BenchmarkEvaluator:
    """
    Renders formatted evaluation metrics and benchmark reports.
    """

    @staticmethod
    def print_summary_report(summary: TaskBatchSummary) -> None:
        """Prints styled summary report to console using Rich."""
        table = Table(title="📊 Self-Learning Agent Evaluation Report", border_style="cyan")
        table.add_column("Metric", style="bold yellow")
        table.add_column("Value", style="bold white")

        table.add_row("Total Tasks Evaluated", str(summary.total_tasks))
        table.add_row("Successful Tasks", f"{summary.successful_tasks} / {summary.total_tasks}")
        table.add_row("Pass@1 Rate (First-Try Success)", f"{summary.pass_at_1_rate}%")
        table.add_row("Average Attempts per Task", f"{summary.avg_attempts_per_task}")
        table.add_row("Total Reflection Lessons in Memory", str(summary.total_lessons_accumulated))

        console.print(table)

        # Print per-task trajectory breakdown
        traj_table = Table(title="📋 Per-Task Execution Trajectory Breakdown", border_style="green")
        traj_table.add_column("Task ID", style="dim")
        traj_table.add_column("Prompt Snippet", style="white")
        traj_table.add_column("Status", style="bold")
        traj_table.add_column("Attempts", style="cyan")
        traj_table.add_column("Lessons Applied", style="magenta")

        for t in summary.trajectories:
            status_style = "green" if t["status"] == "SUCCESS" else "red"
            prompt_snippet = t["prompt"][:40] + "..." if len(t["prompt"]) > 40 else t["prompt"]

            traj_table.add_row(
                t["task_id"][:8],
                prompt_snippet,
                f"[{status_style}]{t['status']}[/{status_style}]",
                str(t["attempts"]),
                str(t["lessons_applied_count"])
            )

        console.print(traj_table)
