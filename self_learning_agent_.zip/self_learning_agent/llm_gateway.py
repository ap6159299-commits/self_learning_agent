"""
LLM Gateway Module.
Provides a provider-agnostic wrapper using google-genai and openai client SDKs.
Enforces structured JSON schema generation and parsing.
"""

import json
import re
from typing import Optional, Dict, Any
from config import settings
from schemas import CodeGenerationRequest, CodeGenerationResult

# Import SDKs gracefully
try:
    from google import genai
    from google.genai import types
    HAS_GENAI = True
except ImportError:
    HAS_GENAI = False

try:
    from openai import AsyncOpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


class LLMGateway:
    """
    Provider-agnostic LLM Gateway.
    Supports Google Gemini (via google-genai) and OpenAI / Ollama (via openai SDK).
    """

    SYSTEM_PROMPT = """You are an expert Senior Python Staff Software Engineer.
Your job is to generate clean, robust, highly performant, and syntactically valid Python 3.11 code to fulfill user tasks.

Rules:
1. Always write complete, runnable Python code without placeholders or missing imports.
2. Provide step-by-step reasoning in `thought_process` before writing the code.
3. Keep explanation concise and technical.
4. Output MUST be valid JSON adhering strictly to the following schema:
{
    "thought_process": "Detailed step-by-step reasoning...",
    "code": "Complete executable Python code...",
    "explanation": "Technical breakdown of the solution..."
}
"""

    def __init__(self, model_name: Optional[str] = None):
        """
        Initialize the LLM Gateway with provider auto-detection.
        
        Args:
            model_name: Optional model override. Defaults to settings.DEFAULT_MODEL.
        """
        self.model_name = model_name or settings.DEFAULT_MODEL

    def _build_user_prompt(self, request: CodeGenerationRequest) -> str:
        """Constructs prompt containing task requirements and optional historical lessons."""
        prompt_parts = [f"### TASK REQUIREMENTS:\n{request.prompt}\n"]

        if request.context_lessons:
            prompt_parts.append("### LESSONS LEARNED FROM PAST ATTEMPTS (IMPORTANT - DO NOT REPEAT THESE MISTAKES):")
            for i, lesson in enumerate(request.context_lessons, 1):
                prompt_parts.append(f"{i}. {lesson}")
            prompt_parts.append("")

        prompt_parts.append("Generate the JSON response containing thought_process, code, and explanation.")
        return "\n".join(prompt_parts)

    def _clean_json_response(self, text: str) -> str:
        """Extracts raw JSON string if model wraps response in markdown block."""
        text = text.strip()
        # Regex to strip ```json ... ``` or ``` ... ``` wrappers
        match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
        if match:
            return match.group(1)
        # Fallback: locate first '{' and last '}'
        start = text.find('{')
        end = text.rfind('}')
        if start != -1 and end != -1 and end > start:
            return text[start:end+1]
        return text

    async def generate_code(self, request: CodeGenerationRequest) -> CodeGenerationResult:
        """
        Asynchronously generates code given a task request and past lessons context.

        Args:
            request: CodeGenerationRequest containing prompt and lessons context.

        Returns:
            Validated CodeGenerationResult Pydantic object.
        """
        user_prompt = self._build_user_prompt(request)
        model_lower = self.model_name.lower()

        raw_content = ""

        # Provider Route 1: Google Gemini Models
        if "gemini" in model_lower:
            if not HAS_GENAI:
                raise ImportError("google-genai package is not installed.")
            
            client = genai.Client(api_key=settings.GEMINI_API_KEY)
            response = client.models.generate_content(
                model=self.model_name.replace("gemini/", ""),
                contents=user_prompt,
                config=types.GenerateContentConfig(
                    system_instruction=self.SYSTEM_PROMPT,
                    temperature=settings.TEMPERATURE,
                    response_mime_type="application/json",
                )
            )
            raw_content = response.text

        # Provider Route 2: OpenAI / Local Models
        else:
            if not HAS_OPENAI:
                raise ImportError("openai package is not installed.")
            
            client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY or "dummy-key")
            response = await client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": self.SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=settings.TEMPERATURE,
                response_format={"type": "json_object"}
            )
            raw_content = response.choices[0].message.content

        cleaned_json = self._clean_json_response(raw_content)
        try:
            data: Dict[str, Any] = json.loads(cleaned_json)
            return CodeGenerationResult.model_validate(data)
        except Exception as e:
            raise ValueError(f"Failed to parse LLM output as CodeGenerationResult: {e}\nRaw output: {raw_content}") from e
