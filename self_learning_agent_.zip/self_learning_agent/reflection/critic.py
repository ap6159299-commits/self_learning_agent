"""
Reflection Engine Module.
Parses code execution failures, performs Root Cause Analysis (RCA),
and synthesizes actionable ReflectionResult objects.
"""

import json
import re
from typing import Optional, Dict, Any
from config import settings
from schemas import ExecutionResult, ReflectionResult, FailureCategory
from llm_gateway import LLMGateway


class ReflectionEngine:
    """
    LLM-powered Critic Engine for failure diagnosis and self-correction lesson generation.
    """

    CRITIC_SYSTEM_PROMPT = """You are an expert Staff Code Critic and Diagnostic Engineer.
Your job is to analyze failed Python code execution attempts and determine EXACTLY why the code failed.

Output MUST be valid JSON adhering strictly to this schema:
{
    "failure_category": "SYNTAX_ERROR" | "RUNTIME_ERROR" | "LOGIC_ERROR" | "TIMEOUT_ERROR" | "UNKNOWN",
    "root_cause": "Concise 1-sentence technical explanation of root cause",
    "lesson_learned": "Explanation of what assumption was wrong",
    "remediation_rule": "Actionable, precise directive rule for future code generation (e.g. 'Always initialize counter variable before loop')"
}
"""

    def __init__(self, llm_gateway: Optional[LLMGateway] = None):
        """
        Initialize Reflection Engine.

        Args:
            llm_gateway: Optional LLMGateway instance.
        """
        self.llm_gateway = llm_gateway or LLMGateway()

    def _determine_category_fallback(self, stderr: str, exit_code: int) -> FailureCategory:
        """Heuristic fallback failure category detector."""
        if exit_code == 124 or "Timeout" in stderr:
            return FailureCategory.TIMEOUT_ERROR
        if "SyntaxError" in stderr or "IndentationError" in stderr:
            return FailureCategory.SYNTAX_ERROR
        if "Error" in stderr or "Exception" in stderr:
            return FailureCategory.RUNTIME_ERROR
        return FailureCategory.UNKNOWN

    async def reflect(self, prompt: str, execution: ExecutionResult) -> ReflectionResult:
        """
        Diagnoses a failed execution attempt and synthesizes a ReflectionResult.

        Args:
            prompt: User task prompt.
            execution: Failed ExecutionResult object.

        Returns:
            Validated ReflectionResult containing remediation rules.
        """
        critic_user_prompt = f"""### TASK PROMPT:
{prompt}

### GENERATED CODE THAT FAILED:
```python
{execution.generated_code}
```

### SANDBOX EXECUTION OUTPUT:
Exit Code: {execution.exit_code}
STDOUT: {execution.stdout or '(none)'}
STDERR: {execution.stderr or '(none)'}

Analyze the failure, perform root cause analysis, and output the structured ReflectionResult JSON.
"""

        # Formulate prompt request for Critic
        try:
            # Re-use LLM Gateway structured JSON parsing
            raw_response = await self.llm_gateway.generate_code(
                request=type('DummyRequest', (), {
                    'prompt': critic_user_prompt,
                    'context_lessons': []
                })()
            )

            # Try parsing raw content as ReflectionResult
            data: Dict[str, Any] = json.loads(self.llm_gateway._clean_json_response(raw_response.thought_process + "\n" + raw_response.explanation))
            return ReflectionResult.model_validate(data)

        except Exception:
            # Fallback reflection if LLM Critic response parsing fails
            category = self._determine_category_fallback(execution.stderr, execution.exit_code)
            root_cause = execution.stderr.strip().split("\n")[-1] if execution.stderr else "Unknown runtime error"

            return ReflectionResult(
                failure_category=category,
                root_cause=root_cause,
                lesson_learned=f"Script failed with exit code {execution.exit_code}: {root_cause}",
                remediation_rule=f"Avoid errors of type {category.value}: {root_cause}"
            )
