"""
Single-Agent Orchestrator Module.
Manages state lifecycle, code synthesis, sandbox execution, SQLite persistence,
and automated self-healing reflection retries.
"""

from typing import Optional, List
from schemas import Task, TaskStatus, AgentState, CodeGenerationRequest, CodeGenerationResult, ExecutionResult, ReflectionResult
from llm_gateway import LLMGateway
from sandbox.python_executor import PythonExecutor
from memory.memory_manager import MemoryManager
from reflection.critic import ReflectionEngine
from config import settings


class CodeAgent:
    """
    Single-Agent Autonomous Coding State Machine.
    Drives task state transitions through memory retrieval, code synthesis, sandbox execution,
    reflection-based failure analysis, and automated self-correction retry loops.
    """

    def __init__(
        self,
        llm_gateway: Optional[LLMGateway] = None,
        executor: Optional[PythonExecutor] = None,
        memory_manager: Optional[MemoryManager] = None,
        reflection_engine: Optional[ReflectionEngine] = None
    ):
        """
        Initialize the agent with dependencies.

        Args:
            llm_gateway: Optional LLMGateway instance.
            executor: Optional PythonExecutor instance.
            memory_manager: Optional MemoryManager instance.
            reflection_engine: Optional ReflectionEngine instance.
        """
        self.llm_gateway = llm_gateway or LLMGateway()
        self.executor = executor or PythonExecutor()
        self.memory_manager = memory_manager or MemoryManager()
        self.reflection_engine = reflection_engine or ReflectionEngine(llm_gateway=self.llm_gateway)

    async def run(self, prompt: str, lessons_context: Optional[List[str]] = None) -> AgentState:
        """
        Executes autonomous task lifecycle with self-correction retry loop.

        Args:
            prompt: User task prompt.
            lessons_context: Optional manual override list of past lesson strings.

        Returns:
            Finalized AgentState container.
        """
        # Step 1: Initialize Task and AgentState
        task = Task(prompt=prompt, status=TaskStatus.IN_PROGRESS)
        
        # Step 2: Retrieve Relevant Past Lessons from Memory
        retrieved_lessons = lessons_context or self.memory_manager.get_relevant_lessons(prompt)

        state = AgentState(
            task=task,
            max_attempts=settings.MAX_RETRIES,
            lessons_applied=list(retrieved_lessons),
            status=TaskStatus.IN_PROGRESS
        )

        # Save initial task to database
        self.memory_manager.save_task(task)

        # Step 3: Self-Correction Retry Loop
        while state.current_attempt <= state.max_attempts:
            request = CodeGenerationRequest(
                prompt=prompt,
                context_lessons=state.lessons_applied
            )

            try:
                # 3a. Synthesize Code
                gen_result: CodeGenerationResult = await self.llm_gateway.generate_code(request)
                state.generated_code = gen_result.code

                # 3b. Execute Code in Sandbox
                exec_result: ExecutionResult = self.executor.execute(
                    task_id=task.id,
                    attempt_number=state.current_attempt,
                    code=gen_result.code
                )

                state.last_execution = exec_result
                self.memory_manager.save_execution(exec_result)

                # 3c. Success Check
                if exec_result.passed:
                    state.status = TaskStatus.SUCCESS
                    state.task.status = TaskStatus.SUCCESS
                    self.memory_manager.save_task(state.task)
                    break  # Task resolved successfully!

                # 3d. Failure Handling & Reflection Trigger
                if state.current_attempt < state.max_attempts:
                    # Trigger Reflection Engine for failure diagnosis
                    reflection: ReflectionResult = await self.reflection_engine.reflect(prompt, exec_result)
                    state.reflections.append(reflection)

                    # Save synthesized lesson to SQLite Memory
                    self.memory_manager.save_lesson(
                        task_id=task.id,
                        execution_id=exec_result.execution_id,
                        failure_category=reflection.failure_category.value,
                        root_cause=reflection.root_cause,
                        lesson_learned=reflection.lesson_learned,
                        remediation_rule=reflection.remediation_rule
                    )

                    # Inject remediation rule into active lessons context for next retry
                    if reflection.remediation_rule not in state.lessons_applied:
                        state.lessons_applied.append(reflection.remediation_rule)

                    state.current_attempt += 1
                else:
                    # Max retries exhausted
                    state.status = TaskStatus.FAILED
                    state.task.status = TaskStatus.FAILED
                    self.memory_manager.save_task(state.task)
                    break

            except Exception as e:
                state.status = TaskStatus.FAILED
                state.task.status = TaskStatus.FAILED
                self.memory_manager.save_task(state.task)
                raise RuntimeError(f"Agent execution error on attempt {state.current_attempt}: {e}") from e

        return state
