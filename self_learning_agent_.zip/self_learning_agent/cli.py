"""
Interactive CLI Interface for the AI Coding Agent using Rich.
Supports single-task runs, sandbox output visualization, and benchmark metric evaluation.
"""

import argparse
import asyncio
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from agent import CodeAgent
from schemas import AgentState, TaskStatus
from evaluation.evaluator import EvaluationHarness

console = Console()


async def main():
    parser = argparse.ArgumentParser(description="Self-Learning AI Coding Agent - Phase 6 CLI")
    parser.add_argument(
        "--prompt", "-p",
        type=str,
        help="Coding task prompt (e.g. 'Write a function for binary search')"
    )
    parser.add_argument(
        "--eval", "-e",
        action="store_true",
        help="Run evaluation harness and display agent benchmark metrics dashboard"
    )
    args = parser.parse_args()

    # Flag Route: Display Evaluation Dashboard
    if args.eval:
        console.print("\n[bold cyan]📊 Running Evaluation Harness...[/bold cyan]\n")
        harness = EvaluationHarness()
        harness.print_report()
        return

    prompt = args.prompt
    if not prompt:
        console.print("[bold cyan]🤖 Self-Learning AI Coding Agent (Phase 6 - Evaluation Framework)[/bold cyan]")
        prompt = console.input("\n[bold yellow]Enter your coding task prompt (or type 'eval' for report):[/bold yellow] ").strip()

    if prompt.lower() in ["eval", "benchmark", "metrics"]:
        harness = EvaluationHarness()
        harness.print_report()
        return

    if not prompt:
        console.print("[red]Task prompt cannot be empty. Exiting.[/red]")
        return

    console.print(f"\n[bold blue]🚀 Processing Task:[/bold blue] {prompt}\n")

    agent = CodeAgent()

    with console.status("[bold green]Synthesizing code, executing in Sandbox & learning...[/bold green]", spinner="dots"):
        try:
            state: AgentState = await agent.run(prompt)
        except Exception as e:
            console.print(f"\n[bold red]❌ Error during agent execution:[/bold red] {e}")
            return

    # Display Generated Code
    if state.generated_code:
        syntax = Syntax(state.generated_code, "python", theme="monokai", line_numbers=True)
        console.print(Panel(syntax, title=f"Generated Python Code (Attempt {state.current_attempt}/{state.max_attempts})", border_style="cyan"))

    # Display Execution Output
    exec_res = state.last_execution
    if exec_res:
        status_color = "green" if exec_res.passed else "red"
        status_text = "PASSED" if exec_res.passed else f"FAILED (Exit Code: {exec_res.exit_code})"

        log_output = ""
        if exec_res.stdout:
            log_output += f"[bold white]STDOUT:[/bold white]\n{exec_res.stdout}\n"
        if exec_res.stderr:
            log_output += f"[bold red]STDERR:[/bold red]\n{exec_res.stderr}\n"

        log_output += f"\n[dim]Latency: {exec_res.execution_time_ms} ms | Applied Lessons: {len(state.lessons_applied)}[/dim]"

        console.print(Panel(
            log_output,
            title=f"Sandbox Execution Result: [{status_color}]{status_text}[/{status_color}]",
            border_style=status_color
        ))


if __name__ == "__main__":
    asyncio.run(main())
