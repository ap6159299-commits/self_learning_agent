"""
Unit tests for ReflectionEngine and automated self-correction retry loop.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from schemas import (
    TaskStatus, AgentState, CodeGenerationResult, ExecutionResult,
    ReflectionResult, FailureCategory
)
from reflection.critic import ReflectionEngine
from agent import CodeAgent
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager


@pytest.mark.asyncio
async def test_reflection_engine_fallback():
    engine = ReflectionEngine()
    failed_exec = ExecutionResult(
        task_id="task-123",
        attempt_number=1,
        generated_code="x = y + 1",
        stdout="",
        stderr="NameError: name 'y' is not defined",
        exit_code=1,
        execution_time_ms=10.0,
        passed=False
    )

    reflection = await engine.reflect(prompt="Compute y + 1", execution=failed_exec)

    assert isinstance(reflection, ReflectionResult)
    assert reflection.failure_category in [FailureCategory.RUNTIME_ERROR, FailureCategory.UNKNOWN]
    assert "y" in reflection.root_cause or "NameError" in reflection.root_cause or "RUNTIME_ERROR" in reflection.remediation_rule


@pytest.mark.asyncio
async def test_agent_self_correction_retry_loop():
    # Mock LLM Gateway
    mock_gateway = MagicMock()
    
    # Attempt 1 returns broken code, Attempt 2 returns working code
    mock_gateway.generate_code = AsyncMock(side_effect=[
        CodeGenerationResult(
            thought_process="Attempt 1: Forgotten variable declaration",
            code="result = count + 1",
            explanation="Uninitialized variable"
        ),
        CodeGenerationResult(
            thought_process="Attempt 2: Fixed variable initialization",
            code="count = 0\nresult = count + 1\nprint(result)",
            explanation="Initialized count before usage"
        )
    ])

    # Mock Sandbox Executor
    mock_executor = MagicMock()
    mock_executor.execute.side_effect = [
        # Execution 1 fails
        ExecutionResult(
            task_id="task-retry-1",
            attempt_number=1,
            generated_code="result = count + 1",
            stdout="",
            stderr="NameError: name 'count' is not defined",
            exit_code=1,
            execution_time_ms=12.0,
            passed=False
        ),
        # Execution 2 passes
        ExecutionResult(
            task_id="task-retry-1",
            attempt_number=2,
            generated_code="count = 0\nresult = count + 1\nprint(result)",
            stdout="1\n",
            stderr="",
            exit_code=0,
            execution_time_ms=15.0,
            passed=True
        )
    ]

    # Mock Reflection Engine
    mock_reflection_engine = MagicMock()
    mock_reflection_engine.reflect = AsyncMock(return_value=ReflectionResult(
        failure_category=FailureCategory.RUNTIME_ERROR,
        root_cause="Uninitialized variable 'count'",
        lesson_learned="Tried to access count before assigning a value",
        remediation_rule="Always initialize count = 0 before using it in expressions"
    ))

    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    agent = CodeAgent(
        llm_gateway=mock_gateway,
        executor=mock_executor,
        memory_manager=memory_manager,
        reflection_engine=mock_reflection_engine
    )

    state: AgentState = await agent.run(prompt="Increment count by 1")

    # Assert self-correction succeeded on Attempt 2
    assert state.status == TaskStatus.SUCCESS
    assert state.current_attempt == 2
    assert len(state.reflections) == 1
    assert "Always initialize count = 0" in state.lessons_applied[0]
    assert state.generated_code == "count = 0\nresult = count + 1\nprint(result)"

    db.close()
