"""
Unit tests for LLMGateway schema parsing, clean JSON extraction, and prompt construction.
"""

import pytest
from unittest.mock import MagicMock, patch
from schemas import CodeGenerationRequest, CodeGenerationResult
from llm_gateway import LLMGateway


def test_llm_gateway_clean_json_parsing():
    gateway = LLMGateway(model_name="gemini/gemini-2.0-flash")

    raw_response = """
    ```json
    {
        "thought_process": "We will write a standard two-pointer solution.",
        "code": "def is_palindrome(s: str) -> bool:\\n    return s == s[::-1]",
        "explanation": "Reverses string s and checks equality."
    }
    ```
    """

    cleaned = gateway._clean_json_response(raw_response)
    assert "thought_process" in cleaned
    assert "is_palindrome" in cleaned


@pytest.mark.asyncio
async def test_llm_gateway_gemini_mock_execution():
    gateway = LLMGateway(model_name="gemini/gemini-2.0-flash")

    mock_response = MagicMock()
    mock_response.text = '{"thought_process": "Mock reasoning", "code": "print(1)", "explanation": "Prints 1"}'

    with patch("google.genai.Client") as mock_client_cls:
        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_response
        mock_client_cls.return_value = mock_client

        request = CodeGenerationRequest(prompt="Print 1")
        result: CodeGenerationResult = await gateway.generate_code(request)

        assert isinstance(result, CodeGenerationResult)
        assert result.code == "print(1)"
        assert result.thought_process == "Mock reasoning"


def test_llm_gateway_prompt_building_with_lessons():
    gateway = LLMGateway(model_name="gemini/gemini-2.0-flash")
    lessons = ["Avoid O(n^2) space complexity", "Handle empty string edge case"]
    request = CodeGenerationRequest(prompt="Reverse string", context_lessons=lessons)

    user_prompt = gateway._build_user_prompt(request)

    assert "Avoid O(n^2) space complexity" in user_prompt
    assert "Handle empty string edge case" in user_prompt
    assert "LESSONS LEARNED FROM PAST ATTEMPTS" in user_prompt
