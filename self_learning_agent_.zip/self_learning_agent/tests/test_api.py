"""
Integration tests for FastAPI REST API endpoints using TestClient.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient
from api import app
from schemas import TaskStatus, CodeGenerationResult, ExecutionResult


client = TestClient(app)


def test_health_check_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy", "service": "self-learning-agent-api"}


def test_run_task_empty_prompt_validation():
    response = client.post("/api/v1/tasks/run", json={"prompt": "   "})
    assert response.status_code == 400
    assert "Prompt string cannot be empty" in response.json()["detail"]


@patch("api.agent.run")
def test_run_task_success_endpoint(mock_agent_run):
    mock_state = MagicMock()
    mock_state.task.id = "task-api-123"
    mock_state.task.prompt = "Write API endpoint"
    mock_state.status = TaskStatus.SUCCESS
    mock_state.current_attempt = 1
    mock_state.generated_code = "print('FastAPI')"
    mock_state.lessons_applied = []
    
    mock_exec = MagicMock()
    mock_exec.stdout = "FastAPI\n"
    mock_exec.stderr = ""
    mock_exec.exit_code = 0
    mock_exec.execution_time_ms = 12.5
    mock_state.last_execution = mock_exec

    mock_agent_run.return_value = mock_state

    response = client.post("/api/v1/tasks/run", json={"prompt": "Write API endpoint"})
    assert response.status_code == 200
    data = response.json()
    assert data["task_id"] == "task-api-123"
    assert data["status"] == "SUCCESS"
    assert data["generated_code"] == "print('FastAPI')"
    assert data["stdout"] == "FastAPI\n"


def test_get_evaluation_metrics_endpoint():
    response = client.get("/api/v1/eval/metrics")
    assert response.status_code == 200
    data = response.json()
    assert "total_tasks" in data
    assert "task_success_rate" in data
    assert "pass_at_1_rate" in data
