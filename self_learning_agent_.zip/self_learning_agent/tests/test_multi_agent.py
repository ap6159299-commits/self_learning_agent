"""
Unit tests for MultiAgentOrchestrator and sub-agents.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from schemas import TaskStatus, AgentState, CodeGenerationResult, ExecutionResult
from agents.multi_agent import MultiAgentOrchestrator
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager


@pytest.mark.asyncio
async def test_multi_agent_orchestrator_flow():
    mock_gateway = MagicMock()
    mock_gateway.generate_code = AsyncMock(return_value=CodeGenerationResult(
        thought_process="1. Plan algorithm\n2. Write code",
        code="print('MultiAgent')",
        explanation="Prints multiagent string"
    ))

    mock_executor = MagicMock()
    mock_executor.execute.return_value = ExecutionResult(
        task_id="multi-task-1",
        attempt_number=1,
        generated_code="print('MultiAgent')",
        stdout="MultiAgent\n",
        stderr="",
        exit_code=0,
        execution_time_ms=10.0,
        passed=True
    )

    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    orchestrator = MultiAgentOrchestrator(
        llm_gateway=mock_gateway,
        executor=mock_executor,
        memory_manager=memory_manager
    )

    state: AgentState = await orchestrator.run(prompt="Write a multi-agent test script")

    assert state.status == TaskStatus.SUCCESS
    assert state.task.status == TaskStatus.SUCCESS
    assert state.generated_code == "print('MultiAgent')"
    assert mock_gateway.generate_code.called
    assert mock_executor.execute.called

    db.close()
