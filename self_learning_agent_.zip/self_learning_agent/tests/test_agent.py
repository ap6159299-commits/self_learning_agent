"""
Unit tests for CodeAgent orchestrator and state machine logic.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from schemas import TaskStatus, AgentState, CodeGenerationResult, ExecutionResult
from agent import CodeAgent
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager


@pytest.mark.asyncio
async def test_agent_run_success():
    mock_gateway = MagicMock()
    mock_gateway.generate_code = AsyncMock(return_value=CodeGenerationResult(
        thought_process="Mock thought",
        code="print('Hello World')",
        explanation="Prints hello world"
    ))

    mock_executor = MagicMock()
    mock_executor.execute.return_value = ExecutionResult(
        task_id="task-1",
        attempt_number=1,
        generated_code="print('Hello World')",
        stdout="Hello World\n",
        stderr="",
        exit_code=0,
        execution_time_ms=10.0,
        passed=True
    )

    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    agent = CodeAgent(
        llm_gateway=mock_gateway,
        executor=mock_executor,
        memory_manager=memory_manager
    )

    state: AgentState = await agent.run(prompt="Write a hello world script")

    assert state.status == TaskStatus.SUCCESS
    assert state.task.status == TaskStatus.SUCCESS
    assert state.generated_code == "print('Hello World')"
    assert state.last_execution is not None
    assert state.last_execution.passed is True
    assert mock_gateway.generate_code.called
    assert mock_executor.execute.called

    db.close()
