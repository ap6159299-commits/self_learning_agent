"""
Unit tests for EvaluationHarness and metric computation.
"""

import pytest
from schemas import Task, TaskStatus, ExecutionResult
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager
from evaluation.evaluator import EvaluationHarness, EvaluationReport


def test_evaluation_harness_metric_formulas():
    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    # Insert sample task
    task = Task(prompt="Test Evaluation Task", status=TaskStatus.SUCCESS)
    memory_manager.save_task(task)

    # Insert execution 1 (Attempt 1 passes)
    exec_1 = ExecutionResult(
        task_id=task.id,
        attempt_number=1,
        generated_code="print('eval')",
        stdout="eval\n",
        stderr="",
        exit_code=0,
        execution_time_ms=10.0,
        passed=True
    )
    memory_manager.save_execution(exec_1)

    # Insert historical lesson
    memory_manager.save_lesson(
        task_id=task.id,
        execution_id=exec_1.execution_id,
        failure_category="RUNTIME_ERROR",
        root_cause="Test root cause",
        lesson_learned="Test lesson",
        remediation_rule="Test rule"
    )

    harness = EvaluationHarness(memory_manager=memory_manager)
    report: EvaluationReport = harness.evaluate()

    assert report.total_tasks == 1
    assert report.successful_tasks == 1
    assert report.task_success_rate == 100.0
    assert report.pass_at_1_count == 1
    assert report.pass_at_1_rate == 100.0
    assert report.total_executions == 1
    assert report.sandbox_pass_rate == 100.0
    assert report.avg_execution_latency_ms == 10.0
    assert report.total_lessons_in_memory == 1

    db.close()
