"""
Unit tests for MemoryManager and SQLite persistence.
"""

import pytest
from schemas import Task, TaskStatus, ExecutionResult
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager


@pytest.fixture
def temp_memory_manager():
    """Provides a fresh MemoryManager backed by an in-memory SQLite DB."""
    db = SQLiteDatabase(db_path=":memory:")
    manager = MemoryManager(db=db)
    yield manager
    db.close()


def test_memory_save_and_retrieve_task(temp_memory_manager):
    task = Task(prompt="Write binary search", status=TaskStatus.IN_PROGRESS)
    temp_memory_manager.save_task(task)

    # Update status to success
    task.status = TaskStatus.SUCCESS
    temp_memory_manager.save_task(task)

    conn = temp_memory_manager.db.get_connection()
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task.id,)).fetchone()
    assert row is not None
    assert row["prompt"] == "Write binary search"
    assert row["status"] == "SUCCESS"


def test_memory_save_execution(temp_memory_manager):
    exec_res = ExecutionResult(
        task_id="task-123",
        attempt_number=1,
        generated_code="print('Memory')",
        stdout="Memory\n",
        stderr="",
        exit_code=0,
        execution_time_ms=15.5,
        passed=True
    )
    temp_memory_manager.save_execution(exec_res)

    conn = temp_memory_manager.db.get_connection()
    row = conn.execute("SELECT * FROM executions WHERE id = ?", (exec_res.execution_id,)).fetchone()
    assert row is not None
    assert row["task_id"] == "task-123"
    assert row["generated_code"] == "print('Memory')"
    assert row["passed"] == 1


def test_memory_save_and_retrieve_lesson(temp_memory_manager):
    lesson_id = temp_memory_manager.save_lesson(
        task_id="task-999",
        execution_id="exec-999",
        failure_category="RUNTIME_ERROR",
        root_cause="ZeroDivisionError when dividing by zero",
        lesson_learned="Always validate denominator != 0 before division",
        remediation_rule="Check if denominator is 0 before division operation"
    )

    assert lesson_id is not None

    lessons = temp_memory_manager.get_relevant_lessons(prompt="Perform division function", limit=3)
    assert len(lessons) > 0
    assert "Check if denominator is 0" in lessons[0]
