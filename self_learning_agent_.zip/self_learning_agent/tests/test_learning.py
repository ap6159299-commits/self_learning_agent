"""
Unit tests for closed-loop self-learning and cross-task memory transfer.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from schemas import (
    TaskStatus, AgentState, CodeGenerationResult, ExecutionResult,
    ReflectionResult, FailureCategory
)
from agent import CodeAgent
from reflection.critic import ReflectionEngine
from memory.sqlite_db import SQLiteDatabase
from memory.memory_manager import MemoryManager
from learning.learning_loop import SelfLearningLoop, TaskBatchSummary


@pytest.mark.asyncio
async def test_cross_task_learning_transfer():
    """
    Verifies that a failure lesson learned in Task 1 is stored in SQLite,
    retrieved for Task 2, and allows Task 2 to pass on Attempt 1.
    """
    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    # 1. Manually insert a historical failure lesson into SQLite Memory
    memory_manager.save_lesson(
        task_id="task-prev-1",
        execution_id="exec-prev-1",
        failure_category=FailureCategory.RUNTIME_ERROR.value,
        root_cause="ZeroDivisionError when denominator is zero",
        lesson_learned="Division by zero causes runtime crash",
        remediation_rule="Always check if denominator == 0 before division"
    )

    # Mock LLM Gateway that inspects incoming prompt lessons
    mock_gateway = MagicMock()
    
    async def mock_generate(request):
        # Verify that historical lesson was retrieved and injected!
        assert any("check if denominator == 0" in lesson.lower() for lesson in request.context_lessons)
        return CodeGenerationResult(
            thought_process="Observed lesson: checking denominator == 0",
            code="def compute_ratio(a, b):\n    if b == 0:\n        return 0.0\n    return a / b\nprint(compute_ratio(10, 2))",
            explanation="Includes zero denominator check"
        )

    mock_gateway.generate_code = AsyncMock(side_effect=mock_generate)

    # Mock Sandbox Executor
    mock_executor = MagicMock()
    mock_executor.execute.return_value = ExecutionResult(
        task_id="task-2",
        attempt_number=1,
        generated_code="def compute_ratio(a, b)...",
        stdout="5.0\n",
        stderr="",
        exit_code=0,
        execution_time_ms=8.0,
        passed=True
    )

    agent = CodeAgent(
        llm_gateway=mock_gateway,
        executor=mock_executor,
        memory_manager=memory_manager
    )

    # Run Task 2
    state: AgentState = await agent.run(prompt="Write a function to compute ratio of two numbers")

    # Assert Task 2 achieved Pass@1 on first attempt due to memory injection!
    assert state.status == TaskStatus.SUCCESS
    assert state.current_attempt == 1
    assert len(state.lessons_applied) > 0
    assert "Always check if denominator == 0" in state.lessons_applied[0]

    db.close()


@pytest.mark.asyncio
async def test_learning_loop_batch_execution():
    db = SQLiteDatabase(db_path=":memory:")
    memory_manager = MemoryManager(db=db)

    mock_gateway = MagicMock()
    mock_gateway.generate_code = AsyncMock(return_value=CodeGenerationResult(
        thought_process="Thought",
        code="print('Batch test')",
        explanation="Prints string"
    ))

    mock_executor = MagicMock()
    
    def side_effect_execute(task_id, attempt_number, code):
        return ExecutionResult(
            task_id=task_id,
            attempt_number=attempt_number,
            generated_code=code,
            stdout="Batch test\n",
            stderr="",
            exit_code=0,
            execution_time_ms=5.0,
            passed=True
        )

    mock_executor.execute.side_effect = side_effect_execute

    agent = CodeAgent(
        llm_gateway=mock_gateway,
        executor=mock_executor,
        memory_manager=memory_manager
    )

    loop = SelfLearningLoop(agent=agent, memory_manager=memory_manager)
    prompts = [
        "Write binary search",
        "Write palindrome check"
    ]

    summary: TaskBatchSummary = await loop.run_batch(prompts)

    assert summary.total_tasks == 2
    assert summary.successful_tasks == 2
    assert summary.pass_at_1_count == 2
    assert summary.pass_at_1_rate == 100.0
    assert summary.avg_attempts_per_task == 1.0

    db.close()
