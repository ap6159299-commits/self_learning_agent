"""
Unit tests for PythonExecutor sandbox module.
"""

import pytest
from sandbox.python_executor import PythonExecutor
from schemas import ExecutionResult


def test_sandbox_successful_execution():
    executor = PythonExecutor(timeout_seconds=5.0)
    code = "print('Hello from Sandbox!')"
    result: ExecutionResult = executor.execute(task_id="task-123", attempt_number=1, code=code)

    assert result.passed is True
    assert result.exit_code == 0
    assert "Hello from Sandbox!" in result.stdout
    assert result.stderr == ""
    assert result.execution_time_ms > 0


def test_sandbox_runtime_error_execution():
    executor = PythonExecutor(timeout_seconds=5.0)
    code = "x = 1 / 0"
    result: ExecutionResult = executor.execute(task_id="task-456", attempt_number=1, code=code)

    assert result.passed is False
    assert result.exit_code != 0
    assert "ZeroDivisionError" in result.stderr


def test_sandbox_timeout_trap_execution():
    executor = PythonExecutor(timeout_seconds=1.0)
    code = "import time\nwhile True:\n    time.sleep(0.1)"
    result: ExecutionResult = executor.execute(task_id="task-789", attempt_number=1, code=code)

    assert result.passed is False
    assert result.exit_code == 124
    assert "Execution Timeout Error" in result.stderr
