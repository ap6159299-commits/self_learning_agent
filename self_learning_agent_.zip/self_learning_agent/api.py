"""
FastAPI Application for the Self-Learning AI Coding Agent.
Exposes RESTful API endpoints for task execution, memory inspection, and evaluation metrics.
"""

from typing import List, Optional
from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
from agent import CodeAgent
from schemas import AgentState, TaskStatus, ExecutionResult
from evaluation.evaluator import EvaluationHarness, EvaluationReport

# Initialize FastAPI application
app = FastAPI(
    title="Self-Learning AI Coding Agent API",
    description="Production REST API for autonomous Python code synthesis, sandbox execution, reflection, and continuous learning.",
    version="1.0.0"
)

# Global Agent and Evaluator instances
agent = CodeAgent()
evaluator = EvaluationHarness()


class TaskRunRequest(BaseModel):
    """HTTP POST payload for triggering a coding task."""
    prompt: str = Field(..., json_schema_extra={"example": "Write a Python function for binary search."})
    lessons_override: Optional[List[str]] = Field(default=None, description="Optional manual lesson override strings")


class TaskRunResponse(BaseModel):
    """HTTP POST response payload containing execution results and state metadata."""
    task_id: str
    prompt: str
    status: TaskStatus
    attempts: int
    generated_code: Optional[str]
    stdout: Optional[str]
    stderr: Optional[str]
    exit_code: Optional[int]
    execution_time_ms: Optional[float]
    applied_lessons_count: int


@app.get("/health", status_code=status.HTTP_200_OK)
async def health_check():
    """Health check endpoint for Docker / K8s probes."""
    return {"status": "healthy", "service": "self-learning-agent-api"}


@app.post("/api/v1/tasks/run", response_model=TaskRunResponse, status_code=status.HTTP_200_OK)
async def run_task(payload: TaskRunRequest):
    """
    Submits a coding task to the agent.
    Triggers memory retrieval, code synthesis, sandbox execution, and reflection retry loops.
    """
    if not payload.prompt.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Prompt string cannot be empty."
        )

    try:
        state: AgentState = await agent.run(
            prompt=payload.prompt,
            lessons_context=payload.lessons_override
        )

        exec_res: Optional[ExecutionResult] = state.last_execution

        return TaskRunResponse(
            task_id=state.task.id,
            prompt=state.task.prompt,
            status=state.status,
            attempts=state.current_attempt,
            generated_code=state.generated_code,
            stdout=exec_res.stdout if exec_res else None,
            stderr=exec_res.stderr if exec_res else None,
            exit_code=exec_res.exit_code if exec_res else None,
            execution_time_ms=exec_res.execution_time_ms if exec_res else None,
            applied_lessons_count=len(state.lessons_applied)
        )

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Agent execution error: {str(e)}"
        )


@app.get("/api/v1/eval/metrics", response_model=EvaluationReport, status_code=status.HTTP_200_OK)
async def get_evaluation_metrics():
    """Returns aggregated performance and benchmark metrics from SQLite database."""
    try:
        return evaluator.evaluate()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to compute evaluation metrics: {str(e)}"
        )
