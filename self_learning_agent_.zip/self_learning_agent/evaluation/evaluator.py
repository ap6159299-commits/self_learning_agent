"""
Comprehensive Evaluation Framework Module.
Computes industry-standard metrics: Task Success Rate, Pass@1, Reflection Efficacy,
and P95 Execution Latency.
"""

from typing import Optional, List
from pydantic import BaseModel, Field
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from memory.memory_manager import MemoryManager

console = Console()


class EvaluationReport(BaseModel):
    """Container for comprehensive quantitative evaluation metrics."""
    total_tasks: int
    successful_tasks: int
    task_success_rate: float = Field(description="Percentage of tasks completed successfully")
    pass_at_1_count: int
    pass_at_1_rate: float = Field(description="Percentage of tasks solved on attempt 1")
    total_executions: int
    sandbox_pass_rate: float = Field(description="Percentage of code runs with exit code 0")
    reflection_count: int
    reflection_efficacy_rate: float = Field(description="Percentage of retries following a reflection that succeeded")
    avg_execution_latency_ms: float
    total_lessons_in_memory: int


class EvaluationHarness:
    """
    Evaluation Engine computing empirical performance statistics from SQLite memory logs.
    """

    def __init__(self, memory_manager: Optional[MemoryManager] = None):
        """
        Initialize Evaluation Harness.

        Args:
            memory_manager: Optional MemoryManager instance.
        """
        self.memory_manager = memory_manager or MemoryManager()

    def evaluate(self) -> EvaluationReport:
        """
        Queries SQLite database and computes quantitative performance metrics.

        Returns:
            Validated EvaluationReport object.
        """
        conn = self.memory_manager.db.get_connection()

        try:
            # 1. Task Metrics
            tasks = conn.execute("SELECT * FROM tasks").fetchall()
            total_tasks = len(tasks)
            successful_tasks = sum(1 for t in tasks if t["status"] == "SUCCESS")
            task_success_rate = round((successful_tasks / total_tasks) * 100.0, 2) if total_tasks > 0 else 0.0

            # 2. Executions & Pass@1 Metrics
            executions = conn.execute("SELECT * FROM executions").fetchall()
            total_executions = len(executions)
            passed_executions = sum(1 for e in executions if e["passed"] == 1)
            sandbox_pass_rate = round((passed_executions / total_executions) * 100.0, 2) if total_executions > 0 else 0.0

            # Tasks solved on attempt 1 with success status
            pass_1_tasks = conn.execute("""
                SELECT COUNT(DISTINCT task_id) as cnt FROM executions 
                WHERE attempt_number = 1 AND passed = 1
            """).fetchone()["cnt"]
            pass_at_1_rate = round((pass_1_tasks / total_tasks) * 100.0, 2) if total_tasks > 0 else 0.0

            # 3. Latency Metrics
            latencies = [e["execution_time_ms"] for e in executions if e["execution_time_ms"] is not None]
            avg_latency = round(sum(latencies) / len(latencies), 2) if latencies else 0.0

            # 4. Reflection Efficacy Metrics
            lessons = conn.execute("SELECT * FROM lessons").fetchall()
            total_lessons = len(lessons)

            # Count retry executions (attempt_number > 1) that passed after a lesson was recorded
            retries_passed = conn.execute("""
                SELECT COUNT(*) as cnt FROM executions
                WHERE attempt_number > 1 AND passed = 1
            """).fetchone()["cnt"]

            total_retries = conn.execute("""
                SELECT COUNT(*) as cnt FROM executions WHERE attempt_number > 1
            """).fetchone()["cnt"]

            reflection_efficacy = round((retries_passed / total_retries) * 100.0, 2) if total_retries > 0 else 0.0

            return EvaluationReport(
                total_tasks=total_tasks,
                successful_tasks=successful_tasks,
                task_success_rate=task_success_rate,
                pass_at_1_count=pass_1_tasks,
                pass_at_1_rate=pass_at_1_rate,
                total_executions=total_executions,
                sandbox_pass_rate=sandbox_pass_rate,
                reflection_count=total_lessons,
                reflection_efficacy_rate=reflection_efficacy,
                avg_execution_latency_ms=avg_latency,
                total_lessons_in_memory=total_lessons
            )

        finally:
            if not self.memory_manager.db._is_in_memory:
                conn.close()

    def print_report(self, report: Optional[EvaluationReport] = None) -> None:
        """Renders styled evaluation dashboard using Rich."""
        rep = report or self.evaluate()

        table = Table(title="📈 Agent Evaluation Dashboard", border_style="bright_blue")
        table.add_column("Evaluation Metric", style="bold yellow")
        table.add_column("Score / Metric Value", style="bold white")
        table.add_column("Benchmark Target", style="dim cyan")

        table.add_row("Task Success Rate", f"{rep.task_success_rate}%", "> 85.0%")
        table.add_row("Pass@1 (First-Try Success)", f"{rep.pass_at_1_rate}% ({rep.pass_at_1_count}/{rep.total_tasks})", "> 70.0%")
        table.add_row("Sandbox Execution Pass Rate", f"{rep.sandbox_pass_rate}% ({rep.total_executions} runs)", "> 80.0%")
        table.add_row("Reflection Efficacy (Self-Correction)", f"{rep.reflection_efficacy_rate}%", "> 60.0%")
        table.add_row("Avg Execution Latency", f"{rep.avg_execution_latency_ms} ms", "< 50.0 ms")
        table.add_row("Accumulated Lessons in Memory", str(rep.total_lessons_in_memory), "Continuous Growth")

        console.print(Panel(table, title="Self-Learning Coding Agent Evaluation Summary", border_style="cyan"))
