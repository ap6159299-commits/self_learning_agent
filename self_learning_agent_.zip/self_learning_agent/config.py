"""
Configuration management system using Pydantic Settings.
Enforces typed environment variable parsing and centralized application settings.
"""

from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application Settings loaded from environment variables and optional .env file.
    """
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

    # API Keys
    GEMINI_API_KEY: Optional[str] = None
    OPENAI_API_KEY: Optional[str] = None
    ANTHROPIC_API_KEY: Optional[str] = None

    # Model Configuration
    # LiteLLM provider format: "gemini/gemini-2.0-flash", "gpt-4o-mini", "claude-3-5-haiku"
    DEFAULT_MODEL: str = "gemini/gemini-2.0-flash"
    TEMPERATURE: float = 0.2

    # Execution & Retry Limits
    MAX_RETRIES: int = 3
    EXECUTION_TIMEOUT_SECONDS: float = 10.0
    MAX_MEMORY_MB: int = 512

    # Database Path
    DB_PATH: str = "agent_storage.db"


# Global settings instance
settings = Settings()
