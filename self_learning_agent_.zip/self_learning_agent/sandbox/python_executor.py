"""
Python Executor Sandbox Module.
Provides isolated, subprocess-based execution of Python code with resource limits and timeout traps.
"""

import sys
import time
import subprocess
import tempfile
from pathlib import Path
from typing import Optional
from config import settings
from schemas import ExecutionResult


class PythonExecutor:
    """
    Subprocess-based Python Code Executor.
    Executes Python scripts safely inside temporary directories with timeout enforcement.
    """

    def __init__(self, timeout_seconds: Optional[float] = None):
        """
        Initialize the executor.

        Args:
            timeout_seconds: Hard execution timeout in seconds. Defaults to config settings.
        """
        self.timeout_seconds = timeout_seconds or settings.EXECUTION_TIMEOUT_SECONDS

    def execute(self, task_id: str, attempt_number: int, code: str) -> ExecutionResult:
        """
        Executes Python code in an isolated subprocess and returns an ExecutionResult.

        Args:
            task_id: Unique task identifier.
            attempt_number: Current retry attempt index.
            code: Executable Python code string.

        Returns:
            Validated ExecutionResult object capturing stdout, stderr, exit_code, and latency.
        """
        # Create an isolated temporary directory for the execution session
        with tempfile.TemporaryDirectory(prefix=f"agent_sandbox_{task_id[:8]}_") as temp_dir:
            script_path = Path(temp_dir) / "script.py"
            script_path.write_text(code, encoding="utf-8")

            start_time = time.perf_counter()

            try:
                # Launch isolated subprocess using current Python executable
                completed_process = subprocess.run(
                    [sys.executable, str(script_path)],
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_seconds,
                    cwd=temp_dir
                )

                elapsed_ms = (time.perf_counter() - start_time) * 1000.0

                return ExecutionResult(
                    task_id=task_id,
                    attempt_number=attempt_number,
                    generated_code=code,
                    stdout=completed_process.stdout,
                    stderr=completed_process.stderr,
                    exit_code=completed_process.returncode,
                    execution_time_ms=round(elapsed_ms, 2),
                    passed=(completed_process.returncode == 0)
                )

            except subprocess.TimeoutExpired as e:
                elapsed_ms = (time.perf_counter() - start_time) * 1000.0
                stdout_captured = e.stdout.decode("utf-8") if isinstance(e.stdout, bytes) else (e.stdout or "")
                stderr_captured = e.stderr.decode("utf-8") if isinstance(e.stderr, bytes) else (e.stderr or "")
                timeout_msg = f"\n[Execution Timeout Error]: Script exceeded limit of {self.timeout_seconds}s."

                return ExecutionResult(
                    task_id=task_id,
                    attempt_number=attempt_number,
                    generated_code=code,
                    stdout=stdout_captured,
                    stderr=stderr_captured + timeout_msg,
                    exit_code=124,  # Standard UNIX timeout exit code
                    execution_time_ms=round(elapsed_ms, 2),
                    passed=False
                )

            except Exception as e:
                elapsed_ms = (time.perf_counter() - start_time) * 1000.0
                return ExecutionResult(
                    task_id=task_id,
                    attempt_number=attempt_number,
                    generated_code=code,
                    stdout="",
                    stderr=f"[Sandbox Exception]: {str(e)}",
                    exit_code=1,
                    execution_time_ms=round(elapsed_ms, 2),
                    passed=False
                )
